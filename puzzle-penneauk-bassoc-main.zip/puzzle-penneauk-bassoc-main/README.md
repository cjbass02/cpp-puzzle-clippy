Team Members:

	Kieran Penneau
	Christian Basso
	Joshua Sopa

Version of C++ used: C++11

Build Tool: CodeLite

Steps to Build:

	Open the project file in CodeLite
	Select "Build" from the top menu bar
	Choose "Configuration Manager" and select "Debug"
	Click "Build" to build the project
	Once the build process completes, the executable can be found in the project's "bin" directory

Entering Debug Mode:
	To enter debug mode, follow these steps:

	Open the project file in CodeLite
	Select "Build" from the top menu bar
	Choose "Configuration Manager" and select "Debug"
	Click "Build" to build the project in debug mode
	From the top menu bar, select "Debug" and choose "Start Debugging"
	The program will run in debug mode, allowing you to step through code, set breakpoints, and inspect variables.

Changes to Game:
	
	We have made several changes to our game from our original design:

	Our program is themed around “coding”
	Clippy acts as the user
	Kernel acts as the monster
	Corrupted files and viruses are hazards
	Our solution also changes the probability of the Kernel moving after they are woken up
	Small changes to the number of debuggers (arrows), their travel distance were also made

Build Tool Version:

	The build system was built using g++ version 11.3.0.